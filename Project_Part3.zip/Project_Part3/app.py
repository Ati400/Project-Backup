# Import the Flask tools we need
from flask import (
    Flask, request, redirect, session,
    send_from_directory, render_template,
    render_template_string, jsonify
)

from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from werkzeug.security import generate_password_hash, check_password_hash
# Import SQLite so we can use our database
import sqlite3

# SPRINT 2 ADDED
# Allows us to read our nutrition and workout HTML files
from pathlib import Path
from datetime import date

# Create our Flask application
app = Flask(__name__)

# Flask needs a secret key to use sessions
# Sessions help us remember who is logged in
app.secret_key = "health_wellness_project"

# Create the users table if it does not already exist

def init_database():
    connection = sqlite3.connect("health_wellness.db")
    cursor = connection.cursor()

    # Users table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL
        )
    """)

    # Workouts table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS workouts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            workout_type TEXT NOT NULL,
            duration INTEGER NOT NULL,
            sets INTEGER,
            reps INTEGER,
            weight REAL,
            entry_date TEXT NOT NULL
        )
    """)

    # Nutrition table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS nutrition (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            food_name TEXT NOT NULL,
            calories INTEGER NOT NULL,
            entry_date TEXT NOT NULL
        )
    """)

    # Water table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS water (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            amount INTEGER NOT NULL,
            entry_date TEXT NOT NULL
        )
    """)

    # Sleep table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS sleep (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            hours REAL NOT NULL,
            entry_date TEXT NOT NULL
        )
    """)

    # Daily goals table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS goals (
            user_id INTEGER PRIMARY KEY,
            water_goal INTEGER NOT NULL,
            workout_goal INTEGER NOT NULL,
            sleep_goal REAL NOT NULL,
            calorie_goal INTEGER NOT NULL
        )
    """)

    # Update older workouts tables with new columns
    cursor.execute("PRAGMA table_info(workouts)")
    existing_columns = [column[1] for column in cursor.fetchall()]

    if "sets" not in existing_columns:
        cursor.execute("ALTER TABLE workouts ADD COLUMN sets INTEGER")

    if "reps" not in existing_columns:
        cursor.execute("ALTER TABLE workouts ADD COLUMN reps INTEGER")

    if "weight" not in existing_columns:
        cursor.execute("ALTER TABLE workouts ADD COLUMN weight REAL")

    connection.commit()
    connection.close()

    
# -----------------------------
# HOME / LOGIN PAGE
# -----------------------------

@app.route("/")
def home():

    # Show the login page
    return send_from_directory(".", "index.html")

# -----------------------------
# LOGIN BACKGROUND IMAGE
# -----------------------------

@app.route("/login-background.png")
def login_background():

    return send_from_directory(".", "login-background.png")
    
# -----------------------------
# REGISTER PAGE
# -----------------------------

@app.route("/register")
def register_page():

    # Show the create account page
    return send_from_directory(".", "register.html")



# -----------------------------
# FORGOT PASSWORD
# -----------------------------

@app.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():

    if request.method == "GET":
        return send_from_directory(".", "forgot_password.html")

    email = request.form.get("email", "").strip()

    connection = tracking_connection()

    user = connection.execute(
        "SELECT id FROM users WHERE LOWER(TRIM(email)) = LOWER(TRIM(?))",
        (email,)
    ).fetchone()

    connection.close()

    if not user:
        return "If the email is registered, a reset link will be available."

    # Generate a temporary reset token
    serializer = URLSafeTimedSerializer(app.secret_key)

    token = serializer.dumps(
        user["id"],
        salt="password-reset"
    )

    # Local classroom demonstration only
    reset_link = f"http://127.0.0.1:5000/reset-password/{token}"

    return f"""
        <h2>LifeTrack Password Reset</h2>
        <p>For local testing, open this reset link:</p>
        <a href="{reset_link}">Reset My Password</a>
        <p>This link expires after 15 minutes.</p>
    """


# -----------------------------
# RESET PASSWORD
# -----------------------------

@app.route("/reset-password/<token>", methods=["GET", "POST"])
def reset_password(token):

    serializer = URLSafeTimedSerializer(app.secret_key)

    try:
        user_id = serializer.loads(
            token,
            salt="password-reset",
            max_age=900
        )

    except (BadSignature, SignatureExpired):
        return "This reset link is invalid or expired.", 400

    if request.method == "GET":
        return render_template_string(
            Path(__file__).with_name("reset_password.html").read_text(
                encoding="utf-8"
            ),
            token=token,
            error=None
        )

    password = request.form.get("password", "")
    confirm_password = request.form.get("confirm_password", "")

    if len(password) < 8 or password != confirm_password:
        return render_template_string(
            Path(__file__).with_name("reset_password.html").read_text(
                encoding="utf-8"
            ),
            token=token,
            error="Passwords must match and contain at least 8 characters."
        )

    connection = tracking_connection()

    connection.execute(
        "UPDATE users SET password = ? WHERE id = ?",
        (generate_password_hash(password), user_id)
    )

    connection.commit()
    connection.close()

    return redirect("/?reset=1")


# -----------------------------
# CREATE ACCOUNT
# -----------------------------

@app.route("/create-account", methods=["POST"])
def create_account():

    # Get the information from the registration form
    name = request.form.get("name")
    email = request.form.get("email")
    password = request.form.get("password")

    # Make sure all fields were entered
    if not name or not email or not password:
        return redirect("/register?error=missing")
    
    # Make sure the password is at least 8 characters
    if len(password) < 8:
        return redirect("/register?error=password")
        
    # Connect to our database
    connection = sqlite3.connect("health_wellness.db")
    cursor = connection.cursor()

    try:

        # Add the new user to the users table
        cursor.execute(
            """
            INSERT INTO users (name, email, password)
            VALUES (?, ?, ?)
            """,
            (name, email, password)
        )

        # Save the new account
        connection.commit()

    except sqlite3.IntegrityError:

        # Close the database
        connection.close()

        # Return to registration page
        # This usually means the email already exists
        return redirect("/register?error=email")

    # Close the database
    connection.close()

    # Send the user to the login page
    return redirect("/?created=1")


# -----------------------------
# LOGIN
# -----------------------------

@app.route("/login", methods=["POST"])
def login():

    # Get the information from the login form
    email = request.form.get("email")
    password = request.form.get("password")

    # Make sure both fields were received
    if not email or not password:
        return redirect("/?error=1")

    # Connect to our database
    connection = sqlite3.connect("health_wellness.db")
    cursor = connection.cursor()

    # Look for an account with this email and password
    cursor.execute("""
        SELECT id, name, email, password
        FROM users
        WHERE email = ?
    """, (email,))

    # Get the account if it exists
    user = cursor.fetchone()

    # Close the database
    connection.close()


    
    # Check if the account was found
    if user and (
        check_password_hash(user[3], password)
        if user[3].startswith(("scrypt:", "pbkdf2:"))
        else user[3] == password
    ):

        # Save information about the logged-in user
        session["user_id"] = user[0]
        session["user_name"] = user[1]

        # Go to the dashboard
        return redirect("/dashboard")



    # If login information was incorrect,
    # return to the login page
    return redirect("/?error=1")



# -----------------------------
# DASHBOARD
# -----------------------------

@app.route("/dashboard")
def dashboard():

    # Make sure the user is logged in
    if "user_id" not in session:
        return redirect("/")

    # Show the dashboard using Flask templates
    return render_template("dashboard.html")


# -----------------------------
# PROFILE
# -----------------------------

@app.route("/profile")
def profile():

    # Make sure the user is logged in
    if "user_id" not in session:
        return redirect("/")

    # Show the profile using Flask templates
    return render_template("profile.html")



# -----------------------------
# USER INFORMATION
# -----------------------------

@app.route("/user")
def get_user():

    # Make sure someone is logged in
    if "user_id" not in session:
        return {
            "name": "",
            "email": ""
        }

    # Get the logged-in user's ID
    user_id = session["user_id"]

    # Connect to the database
    connection = sqlite3.connect("health_wellness.db")
    cursor = connection.cursor()

    # Find the logged-in user's information
    cursor.execute(
        """
        SELECT name, email
        FROM users
        WHERE id = ?
        """,
        (user_id,)
    )

    user = cursor.fetchone()

    # Close the database
    connection.close()


    # Return the user's information
    if user:
        return {
            "name": user[0],
            "email": user[1]
        }

    return {
        "name": "",
        "email": ""
    }


# -----------------------------
# LOGOUT
# -----------------------------

@app.route("/logout")
def logout():

    # Remove the user's login information
    session.clear()

    # Return to the login page
    return redirect("/")


# -----------------------------
# CSS FILE
# -----------------------------

@app.route("/style.css")
def style():

    return send_from_directory(".", "style.css")


# -----------------------------
# JAVASCRIPT FILE
# -----------------------------

@app.route("/script.js")
def script():

    return send_from_directory(".", "script.js")



# ========== SPRINT 2 ADDED ==========

# Connect to the database for nutrition and workouts
def tracking_connection():

    connection = sqlite3.connect("health_wellness.db")

    # Allow us to access columns by their names
    connection.row_factory = sqlite3.Row

    return connection


# -----------------------------
# NUTRITION TRACKING
# -----------------------------

@app.route("/nutrition", methods=["GET", "POST"])
def nutrition():

    # Make sure the user is logged in
    if "user_id" not in session:
        return redirect("/")

    connection = tracking_connection()
    error = None

    # Save food when the form is submitted
    if request.method == "POST":

        food_name = request.form.get("food_name", "").strip()

        try:
            calories = int(request.form.get("calories", ""))

            # Check if the information is valid
            if not food_name or calories < 0:
                raise ValueError

            # Save food for the logged-in user
            connection.execute("""
                INSERT INTO nutrition (user_id, food_name, calories, entry_date)
                VALUES (?, ?, ?, ?)
            """, (
                session["user_id"],
                food_name,
                calories,
                date.today().isoformat()
            ))

            connection.commit()
            connection.close()

            return redirect("/nutrition?saved=1")

        except ValueError:
            error = "Please enter valid food information."
    # Get saved food for this user
    entries = connection.execute("""
        SELECT id, food_name, calories, entry_date
        FROM nutrition
        WHERE user_id = ?
        ORDER BY id DESC
    """, (session["user_id"],)).fetchall()
        
    connection.close()
    # Display nutrition page
    return render_template_string(
        Path(__file__).with_name("nutrition.html").read_text(
            encoding="utf-8"
        ),
        entries=entries,
        error=error,
        saved=request.args.get("saved")
    )


# -----------------------------
# WORKOUT TRACKING
# -----------------------------

@app.route("/workouts", methods=["GET", "POST"])
def workouts():

    # Make sure the user is logged in
    if "user_id" not in session:
        return redirect("/")

    connection = tracking_connection()
    error = None

    # Save workout when the form is submitted
    if request.method == "POST":

        workout_type = request.form.get(
            "workout_type", ""
        ).strip()

        try:
            duration = int(request.form.get("duration", ""))

            
            # Optional strength training information
            sets_text = request.form.get("sets", "").strip()
            reps_text = request.form.get("reps", "").strip()
            weight_text = request.form.get("weight", "").strip()

            sets = int(sets_text) if sets_text else None
            reps = int(reps_text) if reps_text else None
            weight = float(weight_text) if weight_text else None

            if sets is not None and sets <= 0:
                raise ValueError

            if reps is not None and reps <= 0:
                raise ValueError

            if weight is not None and weight < 0:
                raise ValueError

            # Check if workout information is valid
            if not workout_type or duration <= 0:
                raise ValueError
            
            connection.execute("""
                INSERT INTO workouts (
                    user_id, workout_type, duration,
                    sets, reps, weight, entry_date
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                session["user_id"],
                workout_type,
                duration,
                sets,
                reps,
                weight,
                date.today().isoformat()
            ))


            connection.commit()
            connection.close()

            return redirect("/workouts?saved=1")

        except ValueError:
            error = "Please enter valid workout information."

    # Get saved workouts for this user
    entries = connection.execute("""
        SELECT id, workout_type, duration, sets, reps, weight, entry_date
        FROM workouts
        WHERE user_id = ?
        ORDER BY id DESC
    """, (session["user_id"],)).fetchall()

    connection.close()

    # Display workout page
    return render_template_string(
        Path(__file__).with_name("workouts.html").read_text(
            encoding="utf-8"
        ),
        entries=entries,
        error=error,
        saved=request.args.get("saved")
    )




# -----------------------------
# WATER TRACKING
# -----------------------------

@app.route("/water", methods=["GET", "POST"])
def water():

    # Make sure the user is logged in
    if "user_id" not in session:
        return redirect("/")

    connection = tracking_connection()
    error = None

    # Save water intake
    if request.method == "POST":

        try:
            amount = int(request.form.get("amount", ""))

            if amount <= 0:
                raise ValueError

            connection.execute("""
                INSERT INTO water (user_id, amount, entry_date)
                VALUES (?, ?, ?)
            """, (
                session["user_id"],
                amount,
                date.today().isoformat()
))

            connection.commit()
            connection.close()

            return redirect("/water?saved=1")

        except ValueError:
            error = "Please enter a valid water amount."

    # Get saved water entries
    entries = connection.execute("""
        SELECT id,amount, entry_date
        FROM water
        WHERE user_id = ?
        ORDER BY id DESC
    """, (session["user_id"],)).fetchall()

    connection.close()

    return render_template_string(
        Path(__file__).with_name("water.html").read_text(
            encoding="utf-8"
        ),
        entries=entries,
        error=error,
        saved=request.args.get("saved")
    )


# -----------------------------
# SLEEP TRACKING
# -----------------------------

@app.route("/sleep", methods=["GET", "POST"])
def sleep():

    # Make sure the user is logged in
    if "user_id" not in session:
        return redirect("/")

    connection = tracking_connection()
    error = None

    # Save sleep hours
    if request.method == "POST":

        try:
            hours = float(request.form.get("hours", ""))

            if not (0.5 <= hours <= 24):
                raise ValueError

            connection.execute("""
                INSERT INTO sleep (user_id, hours, entry_date)
                VALUES (?, ?, ?)
            """, (
                session["user_id"],
                hours,
                date.today().isoformat()
            ))

            connection.commit()
            connection.close()

            return redirect("/sleep?saved=1")

        except ValueError:
            error = "Please enter valid sleep hours."

    # Get saved sleep entries
    entries = connection.execute("""
        SELECT id,hours, entry_date
        FROM sleep
        WHERE user_id = ?
        ORDER BY id DESC
    """, (session["user_id"],)).fetchall()

    connection.close()

    return render_template_string(
        Path(__file__).with_name("sleep.html").read_text(
            encoding="utf-8"
        ),
        entries=entries,
        error=error,
        saved=request.args.get("saved")
    )

# MY PROGRESS PAGE

@app.route("/progress")
def progress():

    if "user_id" not in session:
        return redirect("/")

    user_id = session["user_id"]
    today = date.today().isoformat()

    conn = tracking_connection()
    
    water_total = conn.execute(
        """
        SELECT COALESCE(SUM(amount), 0)
        FROM water
        WHERE user_id = ? AND substr(entry_date, 1, 10) = ?
        """,
        (user_id, today)
    ).fetchone()[0]
      

    workout_total = conn.execute(
        """
        SELECT COALESCE(SUM(duration), 0)
        FROM workouts
        WHERE user_id = ? AND date(entry_date) = ?
        """,
        (user_id, today)
    ).fetchone()[0]

    sleep_total = conn.execute(
        """
        SELECT COALESCE(SUM(hours), 0)
        FROM sleep
        WHERE user_id = ? AND date(entry_date) = ?
        """,
        (user_id, today)
    ).fetchone()[0]

    calorie_total = conn.execute(
        """
        SELECT COALESCE(SUM(calories), 0)
        FROM nutrition
        WHERE user_id = ? AND date(entry_date) = ?
        """,
        (user_id, today)
    ).fetchone()[0]

    recent_entries = conn.execute(
        """
        SELECT 'Water' AS category,
               CAST(amount AS TEXT) || ' mL' AS details,
               entry_date
        FROM water WHERE user_id = ?

        UNION ALL

        SELECT 'Workout',
               workout_type || ' - ' ||
               CAST(duration AS TEXT) || ' minutes',
               entry_date
        FROM workouts WHERE user_id = ?

        UNION ALL

        SELECT 'Sleep',
               CAST(hours AS TEXT) || ' hours',
               entry_date
        FROM sleep WHERE user_id = ?

        UNION ALL

        SELECT 'Nutrition',
               food_name || ' - ' ||
               CAST(calories AS TEXT) || ' calories',
               entry_date
        FROM nutrition WHERE user_id = ?

        ORDER BY entry_date DESC
        LIMIT 20
        """,
        (user_id, user_id, user_id, user_id)
    ).fetchall()

    conn.close()

    return render_template_string(
        Path(__file__).with_name("progress.html").read_text(
            encoding="utf-8"
        ),
        today=today,
        water_total=water_total,
        workout_total=workout_total,
        sleep_total=sleep_total,
        calorie_total=calorie_total,
        recent_entries=recent_entries
    )

# =====================================
# DELETE TRACKING ENTRY
# =====================================

@app.route("/delete-entry/<category>/<int:entry_id>", methods=["POST"])
def delete_entry(category, entry_id):

    # Make sure the user is logged in
    if "user_id" not in session:
        return redirect("/")

    # Only allow our four tracking tables
    allowed_tables = ["nutrition", "workouts", "water", "sleep"]

    if category not in allowed_tables:
        return "Invalid category", 404

    # Connect to the database
    connection = tracking_connection()

    # Delete only the selected entry belonging to this user
    connection.execute(
        f"DELETE FROM {category} WHERE id = ? AND user_id = ?",
        (entry_id, session["user_id"])
    )

    connection.commit()
    connection.close()

    # Return to the correct tracking page
    return redirect("/" + category)
# ========== SPRINT 3 ADDED ==========

from datetime import timedelta
from flask import jsonify


# -----------------------------
# DAILY GOALS
# -----------------------------

@app.route("/api/goals", methods=["GET", "POST"])
def daily_goals():

    # Make sure the user is logged in
    if "user_id" not in session:
        return jsonify({"error": "Please log in"}), 401

    user_id = session["user_id"]
    connection = tracking_connection()

    # Get saved goals
    if request.method == "GET":

        goals = connection.execute("""
            SELECT water_goal, workout_goal,
                   sleep_goal, calorie_goal
            FROM goals
            WHERE user_id = ?
        """, (user_id,)).fetchone()

        connection.close()

        if goals:
            return jsonify(dict(goals))

        return jsonify({
            "water_goal": 2000,
            "workout_goal": 30,
            "sleep_goal": 8,
            "calorie_goal": 2000
        })

    # Save or update daily goals
    data = request.get_json(silent=True)

    if not isinstance(data, dict):
        connection.close()
        return jsonify({"error": "Invalid goal data"}), 400

    try:
        water_goal = int(data["water_goal"])
        workout_goal = int(data["workout_goal"])
        sleep_goal = float(data["sleep_goal"])
        calorie_goal = int(data["calorie_goal"])

        if not (
            0 < water_goal <= 20000
            and 0 < workout_goal <= 1440
            and 0 < sleep_goal <= 24
            and 0 < calorie_goal <= 20000
        ):
            raise ValueError

    except (ValueError, TypeError, KeyError, OverflowError):
        connection.close()
        return jsonify({"error": "Please enter valid goals"}), 400

    connection.execute("""
        INSERT INTO goals (
            user_id, water_goal, workout_goal,
            sleep_goal, calorie_goal
        )
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(user_id) DO UPDATE SET
            water_goal = excluded.water_goal,
            workout_goal = excluded.workout_goal,
            sleep_goal = excluded.sleep_goal,
            calorie_goal = excluded.calorie_goal
    """, (
        user_id, water_goal, workout_goal,
        sleep_goal, calorie_goal
    ))

    connection.commit()
    connection.close()

    return jsonify({"message": "Goals saved successfully"})


# -----------------------------
# WEEKLY PROGRESS DATA
# -----------------------------

@app.route("/api/weekly-progress")
def weekly_progress():

    # Make sure the user is logged in
    if "user_id" not in session:
        return jsonify({"error": "Please log in"}), 401

    user_id = session["user_id"]

    # Get selected week from the website
    try:
        week_offset = int(request.args.get("week", 0))
    except (ValueError, TypeError):
        return jsonify({"error": "Invalid week"}), 400

    # Prevent users from viewing future weeks
    if week_offset > 0:
        return jsonify({"error": "Future weeks are not available"}), 400

    today = date.today()

    # Find Monday of the current week
    current_monday = today - timedelta(days=today.weekday())

    # Move backward based on selected week
    start_date = current_monday + timedelta(weeks=week_offset)

    # Sunday of selected week
    end_date = start_date + timedelta(days=6)

    connection = tracking_connection()

    categories = {
        "water": ("water", "amount"),
        "workouts": ("workouts", "duration"),
        "sleep": ("sleep", "hours"),
        "nutrition": ("nutrition", "calories")
    }

    results = {}

    for category, (table, column) in categories.items():

        rows = connection.execute(f"""
            SELECT date(entry_date) AS day,
                   SUM({column}) AS total
            FROM {table}
            WHERE user_id = ?
              AND date(entry_date) BETWEEN ? AND ?
            GROUP BY date(entry_date)
        """, (
            user_id,
            start_date.isoformat(),
            end_date.isoformat()
        )).fetchall()

        totals = {
            row["day"]: row["total"]
            for row in rows
        }

        # Use zero for water/workouts/nutrition when no entries exist.
        # Use null for sleep when no sleep was recorded.
        missing_value = None if category in ["sleep", "nutrition"] else 0

        results[category] = [
            totals.get(
                (start_date + timedelta(days=i)).isoformat(),
                missing_value
            )
            for i in range(7)
        ]

    connection.close()

    labels = [
        (start_date + timedelta(days=i)).strftime("%a %m/%d")
        for i in range(7)
    ]

    return jsonify({
        "labels": labels,
        "water": results["water"],
        "workouts": results["workouts"],
        "sleep": results["sleep"],
        "nutrition": results["nutrition"],
        "week_start": start_date.isoformat(),
        "week_end": end_date.isoformat(),
        "week_offset": week_offset
    })



# ========== SPRINT 3: TODAY'S PROGRESS ==========

@app.route("/api/today-progress")
def today_progress():

    if "user_id" not in session:
        return jsonify({"error": "Please log in"}), 401

    user_id = session["user_id"]
    today = date.today().isoformat()

    connection = tracking_connection()

    categories = {
        "water_total": ("water", "amount"),
        "workout_total": ("workouts", "duration"),
        "sleep_total": ("sleep", "hours"),
        "calorie_total": ("nutrition", "calories")
    }

    results = {}

    for name, (table, column) in categories.items():

        total = connection.execute(f"""
            SELECT COALESCE(SUM({column}), 0)
            FROM {table}
            WHERE user_id = ?
              AND date(entry_date) = ?
        """, (user_id, today)).fetchone()[0]

        results[name] = total

    connection.close()

    return jsonify(results)

# ========== END SPRINT 3 ==========

if __name__ == "__main__":
    init_database()
    app.run(debug=True, use_reloader=False)